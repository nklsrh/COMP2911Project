Datei|Neu|Bitmap-Bild, 32x32
Pack 5 - Web Illustrations

Hints:
  Background: Gradient Border
  Symbols: Normal wei� (z.T. 75%)

Digits:
  Symbols: Gradient Black mit Schatten

