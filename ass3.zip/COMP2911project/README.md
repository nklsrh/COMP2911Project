COMP2911 Project - Sudoku game in Java
===============

Sudoku Project for Java study in design and implementation. Presented in the Google Cards UI inspired by Google Now.

<h3>Project Members</h3>
    
    Nikhil Suresh
    Ryan Tan
    Nicholas Ho

<img src="http://i.imgur.com/a1QHSFz.png" height='300'/>
<img src="http://puu.sh/35QAY.png" height='300'/>
